theme: /
    state: ДобавитьСвойПродукт
        q!: добавь свой продукт $FoodName::name на $Amount::weight грамм $AnyText::calInfo
        q!: запиши $FoodName::name $Amount::weight грамм $AnyText::calInfo
        script:
            log('Добавление своего продукта');
            // Извлекаем калории из calInfo (например "200 ккал" или "калорий 200")
            var calMatch = $parseTree._calInfo.match(/(\d+)/);
            var calories = calMatch ? parseInt(calMatch[1]) : 0;
            addCustomFood($parseTree._name, $parseTree._weight, calories, $context);
        random:
            a: "Записал свой продукт"