theme: /
    state: УдалитьПродукт
        q!: (удали | убери | вычеркни) (последнее | последний)
        script:
            log('Удаление последнего');
            deleteLastFood($context);
            q!: (удали | убери | вычеркни) $AnyText::foodName
        script:
            log('Удаление по имени: ' + $parseTree._foodName);
            deleteFoodByName($parseTree._foodName, $context);
        random:
            a: "Удалил"
            a: "Готово, убрал из дневника"